############################### MOHAMED EL EMARY
#Importing all the required libraries
import pygame
import string
import random

#Initializing pygame
pygame.init()

#Screen width and height + shortcut to screen center
screen_width=1275
screen_height=780
sc=(screen_width/2, screen_height/2)

#Creating the window
screen=pygame.display.set_mode((screen_width,screen_height))
#Setting the caption
pygame.display.set_caption("Hangman")

#Background image
background=pygame.image.load("western-background-4.jpg")
#Default font
default_font=pygame.font.SysFont(None, 40)


#Hangman images
images={0:pygame.image.load("1.png"), 1:pygame.image.load("2.png"), 2:pygame.image.load("3.png"), 3:pygame.image.load("4.png"), 4:pygame.image.load("5.png"), 5:pygame.image.load("6.png"), 6:pygame.image.load("7.png")}

#Alphabet
alphabet=list(string.ascii_uppercase)


###################################### MANAR MOHAMED

#Creating class: button
class Button():
    def __init__(self, color, pos, width, height, letter, type=1, font=40 ):
        self.type = type
        self.clicked = False
        self.rollOver = False
        self.font = pygame.font.SysFont(None, 40)
        self.color = color
        self.letter = letter
        self.pos = pos
        self.width = width
        self.height = height
        self.subsurface=pygame.Surface((self.width, self.height))
        self.subsurface.fill(self.color)
        self.text=self.font.render(self.letter,True,(250,250,250))

    def Draw(self, surface):
        if self.type==1:
            if self.rollOver:
                self.subsurface.set_alpha(200)
            else: self.subsurface.set_alpha(255)
            if not self.clicked:
                surface.blit(self.subsurface, self.pos)
                self.subsurface.blit(self.text, (self.width/4, self.height/5))

################################## AHMED WALEED
#Setting colors to the notes and button area
notesArea=pygame.Surface((screen_width, screen_height))
notesArea.fill((240,230,140))
buttonArea=pygame.Surface((screen_width, 100))
buttonArea.fill((255,215,0))

#Creating empty letters list
letters=[]
j=0         #<<<<Aligning the letters vertically
for number, letter in enumerate(alphabet):
    if number>12:     #<<<<Aligning the letters horizontally
        number=number-13
        j=1
    letters.append(Button((139,69,19), (70+number*90, 50+j*100), 50, 50, letter))
#^^^^^^^^Assigning a letter to each button

#List of words to be guessed
words=["APPLE", "ORANGE", "APRICOT", "GRAPES",
       "PLUM", "AVOCADO", "BROCCOLI", "SPINACH",
       "PEAS", "LEMON", "KIWI", "LETTUCE", "TOMATO",
       "CUCUMBER", "WATERMELON", "BANANA", "EGGPLANT",
       "STRAWBERRY", "BLUEBERRY", "MANGO", "CORN",
       "CARROT", "PINEAPPLE", "ORANGE", "PEACH", "GRAPEFRUIT", "CELERY"]
currentWord=random.randrange(0,len(words))

errorCount=0
guessed=[]
widthofthelinefortheletters=40
spacebetweenthelines=10


#Game loop
run=True
while run:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run=False
                pygame.quit()



################################## HABIBA IBRAHIM
###If mouse hovers over the button
            if event.type==pygame.MOUSEMOTION:
                for button in letters:  # BUTTON POSITION GOT BY CALLING GET_RECT()
                    currentRect=button.subsurface.get_rect(topleft=(button.pos[0], button.pos[1]))
                    if currentRect.collidepoint(pygame.mouse.get_pos()):
                        button.rollOver=True            ###Highlight the button only when you are on it
                    else: button.rollOver=False         ###Don't highlight the button if you are not on it

###If mouse presses the button
            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    for button in letters:
                        if button.rollOver == True and button.clicked==False:  ##If the mouse is hovering over the button but hasn't clicked it
                            button.clicked=True
                            guessed.append(button.letter)   #Append the guessed letter in the list "guessed"
                            errorCount = 0     #counter for errors

                            for Chars in guessed :

                                if not(Chars in  words[currentWord]):
                                    errorCount+=1
                                    ###^^^Increase error count by 1 if the user guessed incorrectly



        screen.fill((0,0,0))
        screen.blit(notesArea, (0,0))
        #Drawing the background image
        screen.blit(background, (0,0))
        screen.blit(buttonArea, (0,screen_height))
        ####Drawing the hangman images
        screen.blit(images[errorCount], (sc[0]-images[errorCount].get_rect().width/2, sc[1]-images[errorCount].get_rect().height/2+70))



################################## OMAR MOHAMED
        #Drawing the letters
        for letter in letters:
            letter.Draw(screen)

        #If letter is guessed correctly present it on the screen
        totalShown=0    #Counter for correctly guessed letters that are shown on the screen
        for i, letter in enumerate(words[currentWord]):
            text=default_font.render(letter,True,(0,0,0))   #Render draws text on an existing surface
            posX = (1280 - len(words[currentWord]) * (widthofthelinefortheletters + spacebetweenthelines)) / 2 + i * (widthofthelinefortheletters + spacebetweenthelines)
            posY = 740
            pygame.draw.rect(screen, (0,0,0), (posX, posY, widthofthelinefortheletters, 3))    #<<<Draws the black placeholders for the letters
            ###############Surface^  #Color^   ^Rectangle dimensions  width^            ^height
            if letter in guessed:
                totalShown+=1
                screen.blit(text, (posX+widthofthelinefortheletters/3, posY-30))    #<<Placing the correctly guessed letters in their places


        pygame.display.update()   #Update the display or else the game won't work


        #Setting the "You win" and "You lose" text
        final_font = pygame.font.SysFont(None, 80)
        lose_text = final_font.render("YOU LOSE", True, (128,0,0))
        win_text = final_font.render("YOU GUESSED IT", True, (0,100,0))

        #When the user loses
        if errorCount>=6:
            screen.blit(lose_text, (500,350))
            pygame.display.update()
            pygame.time.wait(1000)  # Slight Delay

            #Resetting everything after losing
            guessed.clear()
            errorCount=0
            for letter in letters:
                letter.clicked=False   #All the clicked buttons reappear
                currentWord=random.randrange(0, len(words))  #Get a new word
            pygame.time.wait(1000)

        #When the user wins
        if totalShown==len(words[currentWord]):   #If the counter for correctly guessed words=length of the word
            screen.blit(win_text, (400,350))
            pygame.display.update()
            pygame.time.wait(1000)

            #Resetting everything after winning
            guessed.clear()
            errorCount=0
            for letter in letters:
                letter.clicked=False
            currentWord=random.randrange(0, len(words))
            pygame.time.wait(1000)
